const productos = [
  {
    id: 1,
    nombre: "Warhammer 40k Space Marine 2",
    precio: 189900,
    categoria: "Acción",
    img: "W40k.jpg"
  },
  {
    id: 2,
    nombre: "Dragon ball Sparking Zero",
    precio: 30000,
    categoria: "Aventura",
    img: "SZ.jpg"
  },
  {
    id: 3,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 4,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 5,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 6,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 7,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 8,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 9,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 10,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 11,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 12,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 13,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 14,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 15,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 16,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 17,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 18,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 19,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 20,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 21,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 22,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 23,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 24,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 25,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 26,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 27,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 28,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 29,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 30,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 31,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 32,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 33,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 34,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 35,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 36,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 37,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 38,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 39,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  },
  {
    id: 40,
    nombre: "Juego B",
    precio: 30000,
    categoria: "Aventura",
    img: "img2.jpg"
  }
  // ...
];
